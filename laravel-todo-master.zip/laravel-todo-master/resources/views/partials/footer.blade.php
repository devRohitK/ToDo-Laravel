<hr/>

<div class="container">
    &copy; {{ date('Y') }}, <a href="https://www.linkedin.com/in/devrohitkr">Rohit Kumar</a>
    <br/>
</div>